module runtime-example-conformance-service-core-workspace/lib

go 1.18

require (
	github.com/teaql/teaql-golang v0.1.10
)